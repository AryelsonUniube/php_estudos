<?php 
include("conexao.php");
$cpf =$_POST['cpf'];
$sql ="Delete * from usuarios where cpf=$cpf";
header("Location cadastro.php");
?>